CREATE PROCEDURE `sp2`()
  select version()
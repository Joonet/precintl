CREATE PROCEDURE `RemoveUserAndReturnUserNums`(`p_id` INT(10) UNSIGNED)
  begin
delete from tdb_goods where goods_id = p_id;
select count(goods_id) from tdb_goods into userNums;
end
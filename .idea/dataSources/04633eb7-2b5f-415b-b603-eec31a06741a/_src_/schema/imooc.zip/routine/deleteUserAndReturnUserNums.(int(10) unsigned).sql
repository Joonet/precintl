CREATE PROCEDURE `deleteUserAndReturnUserNums`(`p_id` INT(10) UNSIGNED)
  begin delete from tdb_goods where cate_id = p_id; select count(cate_id) from tdb_goods into userNums; end
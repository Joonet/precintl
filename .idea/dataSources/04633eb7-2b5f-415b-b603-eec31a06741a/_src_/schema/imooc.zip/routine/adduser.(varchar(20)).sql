CREATE FUNCTION `adduser`(`username` VARCHAR(20))
  RETURNS INT(10) UNSIGNED
begin
insert test(username) values(username);
return last_insert_id();
end
CREATE PROCEDURE `removeUserByID`(`mid` INT(10) UNSIGNED)
  begin
delete from tdb_goods where goods_id = mid;
end
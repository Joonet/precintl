CREATE FUNCTION `f1`()
  RETURNS VARCHAR(30)
return date_format(now(),'%Y年%m月%d日 %H时%i分%s秒')